from django.shortcuts import redirect, render
from django.http import HttpResponse, HttpRequest
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as d_login
from django.contrib import messages
from django.core.mail import send_mail
from .models import Item , Document , reservation , KMCH,PSG
import pymongo
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from datetime import datetime
from django.views.generic import TemplateView
from backend.chat import  chat
from pymongo import MongoClient

client = pymongo.MongoClient()
db = client['myDb']
col = db['purchase']

def home(request):
    if request.method == "POST":
        name = request.POST['name']
        age = request.POST['age']
        contact = request.POST['number']
        email = request.POST['email']
        hospital = request.POST['hospital']
        time = request.POST['time']
        new = reservation(name=name, age=age, contact=contact,email=email,hospital=hospital,time = time)
        new.save()
        if request.POST['hospital'] == "KMCH":
            
            new_KMCH = KMCH(time=time,pname=name)
            new_KMCH.save()
            send_mail('Medical Chatbot',f'Patient {name} has booked appointment for {time}','anuragav754@gmail.com',['anuragav829@gmail.com'],fail_silently=True)
            send_mail('Medical Chatbot',f'You appointment is booked at {time} at {hospital}','anuragav754@gmail.com',[email],fail_silently=True)
        if request.POST['hospital'] == "PSG":

            new_PSG = PSG(time=time,pname=name)
            new_PSG.save()
            send_mail('Medical Chatbot',f'Patient {name} has booked appointment for {time}','anuragav754@gmail.com',['ragav2706@gmail.com'],fail_silently=True)
            send_mail('Medical Chatbot',f'You appointment is booked at {time} at {hospital}','anuragav754@gmail.com',[email],fail_silently=True)
    if request.method=="GET":
        return render (request,'website/home.html')
    return render(request,'website/home.html')

def login(request):
    if request.method == "POST":
        global email
        email = request.POST['email']
        password = request.POST['password']
        user = authenticate(username=email, password=password)
        if user:
            print(user)
            d_login(request,user)
            global user_id 
            user_id = request.user.id
            return render(request, 'website/home.html')
        else:
            messages.info(request,"Wrong Credentials")
            return redirect('login')

    return render(request, 'website/login.html')

def signup(request):
    global email
    if request.method == "POST":
        name = request.POST['username']
        email = request.POST['mail']
        password = request.POST['password']
        if User.objects.filter(username=email).count() > 0:
            messages.error(request,"User Already Exists")
        else:
            user = User.objects.create_user(email, email, password)
            user.first_name = name
            user.save()
            send_mail('Medical Chatbot',f'You have successfully signed up at our website','anuragav754@gmail.com',[email],fail_silently=False)
            global user_id 
            user_id = request.user.id
            return render(request, 'website/home.html')


    return render(request, 'website/signup.html')

def purchase(request):
    if request.method=='POST':
        address = request.POST['address']
        pincode = request.POST['pin']
        scl = Item.objects.all()
        l=[]
        for i in scl:
            l.append(request.POST[i.name])
        print(l)
        d = datetime.now()
        d1= {'date':d,'name':email}
        total =0
        for i in range(len(scl)):
            if l[i]!='':
                d1[scl[i].name]=[int(l[i]),int(l[i])*scl[i].price]
                total += int(l[i])*scl[i].price
        d1['total'] = total
        d1['address'] = address
        d1['pincode']  = pincode
        col.insert_one(d1)
        x = col.find_one({'date':d},{'_id':0,'date':0})
        return render(request, "website/bill.html",{'x':x}) 
    scl = Item.objects.all()
    return render(request,"website/purchase.html",{'scl':scl})

def bill(request):
    res = col.find()
    res = (res.sort("_id",-1))
    if request.method == 'POST':
        send_mail('Medical Chatbot',f'Your ordYou will receive your order within 5 business days ','anuragav754@gmail.com',[email],fail_silently=False)
        messages.info(request,"Done")
        return render(request,'website/home.html')
    return render(request,'website/bill.html')

def documents(request):
    user = email
    print(user)
    scl = Document.objects.filter(user = user)
    if request.method == 'POST' and request.FILES['file']:
        title = request.POST.get('title')
        file = request.FILES.get('file')
        doc = Document(title=title,file=file,user=user)
        doc.save()
        messages.info(request,"Done")
        return redirect('documents')
    else:
        for i in scl:
            print(i.file)
        return render(request,'website/documents.html',{'scl':scl})

class mainpage(TemplateView):
	Template_view="website/chatbot.html"

	def get(self,request):
		return render(request,self.Template_view)

	def post(self,request):
		if request.method == 'POST':
			user = request.POST.get('input',False)
			context={"user":user,"bot":chat(request)}
			
		return render(request,self.Template_view,context)


