from django.db import models
from django.contrib.auth.models import User
from datetime import datetime 

# Create your models here.

class Item(models.Model):
    name = models.CharField(max_length=255)
    price = models.IntegerField()
    image_link = models.URLField(default='')
    def __str__(self):
        return self.name

class reservation(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(null=True)
    age = models.IntegerField()
    contact = models.IntegerField()
    hospital = models.CharField(max_length=255)
    time = models.TimeField()
    def __str__(self):
        return self.name

class PSG(models.Model):
    time = models.TimeField(null=True)
    pname = models.CharField(max_length=255)
    def __str__(self):
        return self.pname + " " +str(self.time)

class KMCH(models.Model):
    time = models.TimeField(null=True)
    pname = models.CharField(max_length=255)
    def __str__(self):
        return self.pname + " " +str(self.time)

class Document(models.Model):
    title = models.CharField(max_length=100)
    file = models.FileField(upload_to = 'media')
    user = models.EmailField(max_length=255,default='')
    def __str__(self):
        return self.title




